// "use client";
// import { useState, useEffect } from "react";
// import PageHeader from "../../../components/ui/PageHeader";
// import {
//     Info, ShieldCheck, Zap,
//     ArrowLeft, RefreshCw, Check, Calendar, ArrowRight, Mail, AlertCircle
// } from "lucide-react";
// import { useRouter } from "next/navigation";
// import PermissionGuardian from "../../../components/auth/PermissionGuardian";
// import { useCreateCouponMutation } from "../../../redux/service/adminApi";

// export default function AddCouponPage() {
//     const router = useRouter();
//     const [createCoupon, { isLoading }] = useCreateCouponMutation();
//     const [activeTab, setActiveTab] = useState("information");
//     const [error, setError] = useState("");

//     const getLiveDateTime = () => {
//         const now = new Date();
//         now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
//         return now.toISOString().slice(0, 16);
//     };

//     const [minDateTime, setMinDateTime] = useState(getLiveDateTime());

//     useEffect(() => {
//         const timer = setInterval(() => setMinDateTime(getLiveDateTime()), 60000);
//         return () => clearInterval(timer);
//     }, []);

//     const [formData, setFormData] = useState({
//         name: "", description: "", code: "",
//         validFrom: getLiveDateTime(),
//         validTill: "",
//         minCartAmount: 0, totalUsageLimit: 1, perUserUsageLimit: 1,
//         allowedCustomers: "",
//         discountType: "1", discountValue: 0
//     });

//     //    Validation Helper: Runs specific checks based on the tab
//     const validateStep = (tab) => {
//         if (tab === "information") {
//             if (!formData.name.trim()) return "Promotional Rule Name is required.";
//             if (!formData.code.trim()) return "Coupon Code is required.";
//             if (formData.code.length < 3) return "Code must be at least 3 characters.";
//         }

//         if (tab === "conditions") {
//             if (!formData.validTill) return "Expiry Date (Valid Till) is required.";
//             if (new Date(formData.validTill) <= new Date(formData.validFrom)) {
//                 return "Expiry time must be after the start time.";
//             }
//             if (formData.totalUsageLimit < 1) return "Global Quota must be at least 1.";

//             // Validate Emails if provided
//             if (formData.allowedCustomers.trim()) {
//                 const emails = formData.allowedCustomers.split(",").map(e => e.trim());
//                 const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//                 const invalidEmail = emails.find(email => !emailRegex.test(email));
//                 if (invalidEmail) return `Invalid email detected: ${invalidEmail}`;
//             }
//         }

//         if (tab === "actions") {
//             if (formData.discountValue <= 0) return "Discount value must be greater than 0.";
//             if (formData.discountType === "1" && formData.discountValue > 100) {
//                 return "Percentage discount cannot exceed 100%.";
//             }
//         }

//         return null;
//     };

//     const handleDateChange = (field, value) => {
//         const selectedTime = new Date(value).getTime();
//         const currentTime = new Date().getTime();

//         if (selectedTime < currentTime && field === 'validFrom') {
//             setFormData(prev => ({ ...prev, [field]: getLiveDateTime() }));
//             setError("Start time cannot be in the past.");
//         } else {
//             setFormData(prev => ({ ...prev, [field]: value }));
//             setError("");
//         }
//     };

//     const handleUpdate = (field, value) => {
//         setFormData(prev => ({ ...prev, [field]: value }));
//         setError("");
//     };

//     const handleNext = (nextTab) => {
//         const validationError = validateStep(activeTab);
//         if (validationError) {
//             setError(validationError);
//             return;
//         }
//         setActiveTab(nextTab);
//         setError("");
//     };

//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         const finalError = validateStep("actions");
//         if (finalError) {
//             setError(finalError);
//             return;
//         }

//         const submissionData = {
//             ...formData,
//             allowedCustomers: formData.allowedCustomers
//                 ? formData.allowedCustomers.split(",").map(email => email.trim()).filter(e => e !== "")
//                 : []
//         };

//         try {
//             await createCoupon(submissionData).unwrap();
//             router.push("/coupon/list");
//         } catch (err) {
//             setError(err?.data?.message || "Internal Server Error: Could not save coupon.");
//         }
//     };

//     const generateCode = () => {
//         if (!formData.name.trim()) {
//             setError("Rule Name is required to generate a code.");
//             return;
//         }
//         const prefix = formData.name.split(" ")[0].toUpperCase().replace(/[^A-Z0-9]/g, "");
//         const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase();
//         handleUpdate('code', `${prefix}${randomStr}`);
//     };

//     return (
//         <PermissionGuardian permissionId="coupons">
//             <main className="min-h-screen bg-gray-50/50 p-3 sm:p-6 md:p-8 lg:p-10 overflow-x-hidden">
//                 <div className="w-full mb-8 flex flex-col sm:flex-row items-center justify-between gap-6 border-b border-gray-100 pb-8">
//                     <div className="text-center sm:text-left">
//                         <PageHeader title="Publish Discount Rule" description="Configure campaign validity and reward logic." />
//                         <div className="w-24 h-1.5 bg-indigo-600 rounded-full mt-4 mx-auto sm:mx-0" />
//                     </div>
//                 </div>

//                 <div className="w-full space-y-6">
//                     {error && (
//                         <div className="p-4 bg-red-50 border-2 border-red-100 text-red-600 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
//                             <AlertCircle size={18} /> {error}
//                         </div>
//                     )}

//                     <div className="overflow-x-auto scrollbar-hide -mx-3 px-3 sm:mx-0 sm:px-0">
//                         <div className="inline-flex gap-2 p-1.5 bg-white rounded-3xl border border-gray-100 shadow-xl shadow-gray-500/5 min-w-full sm:min-w-max lg:w-fit">
//                             <TabButton active={activeTab === "information"} onClick={() => setActiveTab("information")} icon={<Info size={18} />} label="1. Information" />
//                             <TabButton active={activeTab === "conditions"} onClick={() => {
//                                 const err = validateStep("information");
//                                 if (!err) setActiveTab("conditions"); else setError(err);
//                             }} icon={<ShieldCheck size={18} />} label="2. Conditions" />
//                             <TabButton active={activeTab === "actions"} onClick={() => {
//                                 const err = validateStep("information") || validateStep("conditions");
//                                 if (!err) setActiveTab("actions"); else setError(err);
//                             }} icon={<Zap size={18} />} label="3. Actions" />
//                         </div>
//                     </div>

//                     <form onSubmit={handleSubmit} className="bg-white rounded-[2rem] sm:rounded-[2.5rem] border border-gray-100 shadow-2xl overflow-hidden">
//                         <div className="p-5 sm:p-10 lg:p-16">
//                             {activeTab === "information" && (
//                                 <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 lg:gap-12 animate-in fade-in duration-300">
//                                     <div className="space-y-6 sm:space-y-8">
//                                         <InputField label="Promotional Rule Name *" placeholder="e.g. Winter Sale 2026" value={formData.name} onChange={(e) => handleUpdate('name', e.target.value)} />
//                                         <div className="flex flex-col sm:flex-row items-end gap-4">
//                                             <div className="w-full"><InputField label="Public Coupon Code *" placeholder="WINTER50" value={formData.code} onChange={(e) => handleUpdate('code', e.target.value.toUpperCase().replace(/\s/g, ""))} /></div>
//                                             <button type="button" onClick={generateCode} className="w-full sm:w-auto h-14 sm:h-16 px-10 bg-indigo-50 text-indigo-600 border-2 border-indigo-100 rounded-2xl font-black uppercase text-[11px] tracking-widest hover:bg-indigo-600 hover:text-white transition-all">Auto-Gen</button>
//                                         </div>
//                                     </div>
//                                     <div className="space-y-3">
//                                         <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Internal Description ({formData.description.length}/120)</label>
//                                         <textarea maxLength={120} rows={5} className="text-black w-full p-6 sm:p-8 bg-gray-50/50 border-2 border-gray-100 rounded-[2rem] focus:outline-none focus:border-indigo-500 transition-all font-medium text-base leading-relaxed" placeholder="Briefly describe the purpose of this discount..." value={formData.description} onChange={(e) => handleUpdate('description', e.target.value)} />
//                                     </div>
//                                 </div>
//                             )}

//                             {activeTab === "conditions" && (
//                                 <div className="space-y-10 lg:space-y-12 animate-in fade-in duration-300 text-black">
//                                     <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 lg:gap-12">
//                                         <div className="space-y-4">
//                                             <label className="text-[11px] font-black text-gray-400 uppercase tracking-widest ml-1">Validity Window *</label>
//                                             <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_1fr] items-center gap-3">
//                                                 <div className="relative w-full">
//                                                     <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-500" size={18} />
//                                                     <input min={minDateTime} type="datetime-local" className="text-black w-full pl-12 pr-3 h-14 sm:h-16 bg-gray-50/50 border-2 border-gray-100 rounded-2xl font-bold text-xs sm:text-sm focus:border-indigo-500 outline-none transition-all" value={formData.validFrom} onChange={(e) => handleDateChange('validFrom', e.target.value)} />
//                                                 </div>
//                                                 <span className="text-[10px] font-black text-gray-300 uppercase text-center">To</span>
//                                                 <div className="relative w-full">
//                                                     <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-500" size={18} />
//                                                     <input min={formData.validFrom || minDateTime} type="datetime-local" className="text-black w-full pl-12 pr-3 h-14 sm:h-16 bg-gray-50/50 border-2 border-gray-100 rounded-2xl font-bold text-xs sm:text-sm focus:border-indigo-500 outline-none transition-all" value={formData.validTill} onChange={(e) => handleDateChange('validTill', e.target.value)} />
//                                                 </div>
//                                             </div>
//                                         </div>
//                                         <InputField label="Minimum Cart Value (₹)" type="number" min="0" value={formData.minCartAmount} onChange={(e) => handleUpdate('minCartAmount', e.target.value)} />
//                                     </div>

//                                     <div className="pt-10 border-t border-gray-50">
//                                         <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 lg:gap-12 items-start">
//                                             <div className="xl:col-span-2">
//                                                 <InputField label="Target Customers (Comma separated emails)" placeholder="user1@gmail.com, user2@gmail.com" value={formData.allowedCustomers} onChange={(e) => handleUpdate('allowedCustomers', e.target.value)} />
//                                                 <p className="text-[9px] font-bold text-gray-400 uppercase mt-3 ml-1 flex items-center gap-1.5"><Mail size={10} /> Leave empty to make this coupon public for everyone.</p>
//                                             </div>
//                                             <div className="grid grid-cols-2 gap-4">
//                                                 <InputField label="Total Uses" type="number" min="1" value={formData.totalUsageLimit} onChange={(e) => handleUpdate('totalUsageLimit', e.target.value)} />
//                                                 <InputField label="Per User" type="number" min="1" value={formData.perUserUsageLimit} onChange={(e) => handleUpdate('perUserUsageLimit', e.target.value)} />
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             )}

//                             {activeTab === "actions" && (
//                                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12 animate-in fade-in duration-300 ">
//                                     <div className="lg:col-span-2 space-y-6">
//                                         <label className="text-[11px] font-black text-gray-400 uppercase tracking-widest block ml-1">Discount Calculation</label>
//                                         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
//                                             <RadioOption label="Percentage (%)" active={formData.discountType === "1"} onClick={() => handleUpdate('discountType', "1")} />
//                                             <RadioOption label="Fixed Amount (₹)" active={formData.discountType === "2"} onClick={() => handleUpdate('discountType', "2")} />
//                                         </div>
//                                     </div>
//                                     <InputField label={`Discount Value ${formData.discountType === "1" ? "(Max 100%)" : "(Flat ₹)"}`} type="number" min="1" value={formData.discountValue} onChange={(e) => handleUpdate('discountValue', e.target.value)} />
//                                 </div>
//                             )}
//                         </div>

//                         <div className="p-6 sm:p-8 lg:p-12 bg-gray-50/50 border-t border-gray-100 flex justify-end">
//                             <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
//                                 {activeTab !== "information" && (
//                                     <button type="button" onClick={() => setActiveTab(activeTab === "actions" ? "conditions" : "information")} className="w-full sm:w-auto hover:cursor-pointer px-10 py-4 sm:py-5 text-gray-400 font-black uppercase text-[10px] tracking-widest hover:text-indigo-600 transition-all text-center">Back</button>
//                                 )}
//                                 {activeTab === "actions" ? (
//                                     <button type="submit" disabled={isLoading} className="w-full sm:w-auto hover:cursor-pointer px-12 py-4 sm:py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50">
//                                         {isLoading ? <RefreshCw className="animate-spin" size={16} /> : <Check size={18} />} Publish Rule
//                                     </button>
//                                 ) : (
//                                     <button type="button" onClick={() => handleNext(activeTab === "information" ? "conditions" : "actions")} className="w-full sm:w-auto hover:cursor-pointer px-12 py-4 sm:py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95">
//                                         Save & Continue <ArrowRight size={18} />
//                                     </button>
//                                 )}
//                             </div>
//                         </div>
//                     </form>
//                 </div>
//             </main>
//         </PermissionGuardian>
//     );
// }

// /* Internal Components (Maintaining Original Premium Design) */
// const TabButton = ({ active, onClick, icon, label }) => (
//     <button onClick={onClick} type="button" className={`flex-1 flex items-center justify-center hover:cursor-pointer gap-2 sm:gap-3 px-6 sm:px-10 py-3 sm:py-5 rounded-[1.2rem] transition-all whitespace-nowrap ${active ? 'bg-indigo-600 text-white shadow-xl scale-[1.02]' : 'text-gray-400 hover:bg-gray-50'}`}>
//         <span className="opacity-70">{icon}</span>
//         <span className="text-[9px] sm:text-[11px] font-black uppercase tracking-widest">{label}</span>
//     </button>
// );

// const InputField = ({ label, onChange, ...props }) => (
//     <div className="flex flex-col gap-2 sm:gap-3 w-full text-black">
//         <label className="text-[10px] sm:text-[11px] font-black text-gray-400 uppercase tracking-widest ml-1">{label}</label>
//         <input {...props} onChange={onChange} className="w-full h-14 sm:h-16 px-5 sm:px-8 bg-gray-50/50 border-2 border-gray-100 rounded-2xl focus:outline-none focus:border-indigo-500 font-bold sm:font-black text-sm sm:text-lg transition-all" />
//     </div>
// );

// const RadioOption = ({ label, active, onClick }) => (
//     <button onClick={onClick} type="button" className={`flex items-center gap-3 sm:gap-4 p-4 sm:p-6 rounded-[1.5rem] border-2 transition-all w-full ${active ? 'border-indigo-600 bg-indigo-50 shadow-md' : 'border-gray-100 bg-white'}`}>
//         <div className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full border-4 flex items-center justify-center ${active ? 'border-indigo-600 bg-indigo-600 shadow-sm' : 'border-gray-200 bg-white'}`}>
//             {active && <div className="w-2 h-2 rounded-full bg-white" />}
//         </div>
//         <span className={`text-[10px] sm:text-[12px] font-black uppercase tracking-wider ${active ? 'text-gray-900' : 'text-gray-400'}`}>{label}</span>
//     </button>
// );


"use client";
import { useState, useEffect, useMemo } from "react";
import PageHeader from "../../../components/ui/PageHeader";
import {
    Info, ShieldCheck, Zap,
    ArrowLeft, RefreshCw, Check, Calendar, ArrowRight, Mail, AlertCircle, UserCircle2
} from "lucide-react";
import { useRouter } from "next/navigation";
import PermissionGuardian from "../../../components/auth/PermissionGuardian";
import { useCreateCouponMutation, useGetAdminsQuery } from "../../../redux/service/adminApi";


export default function AddCouponPage() {
    const router = useRouter();
    const [createCoupon, { isLoading }] = useCreateCouponMutation();
    
    // Fetch Sub-Admins for the referral dropdown
        const { data: subAdminResponse } = useGetAdminsQuery();
        // Extract the array from the nested 'admins' property and filter by role
        const subAdmins = useMemo(() => {
            return subAdminResponse?.data?.admins?.filter(admin => admin.role === "SUBADMIN") || [];
        }, [subAdminResponse]);

    const [activeTab, setActiveTab] = useState("information");
    const [error, setError] = useState("");

    const getLiveDateTime = () => {
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        return now.toISOString().slice(0, 16);
    };

    const [minDateTime, setMinDateTime] = useState(getLiveDateTime());

    useEffect(() => {
        const timer = setInterval(() => setMinDateTime(getLiveDateTime()), 60000);
        return () => clearInterval(timer);
    }, []);

    const [formData, setFormData] = useState({
        name: "", description: "", code: "",
        validFrom: getLiveDateTime(),
        validTill: "",
        minCartAmount: 0, totalUsageLimit: 1, perUserUsageLimit: 1,
        allowedCustomers: "",
        discountType: "1", discountValue: 0,
        assignedSubAdmin: "" // New field for referral tracking
    });

    const validateStep = (tab) => {
        if (tab === "information") {
            if (!formData.name.trim()) return "Promotional Rule Name is required.";
            if (!formData.code.trim()) return "Coupon Code is required.";
            if (formData.code.length < 3) return "Code must be at least 3 characters.";
        }

        if (tab === "conditions") {
            if (!formData.validTill) return "Expiry Date (Valid Till) is required.";
            if (new Date(formData.validTill) <= new Date(formData.validFrom)) {
                return "Expiry time must be after the start time.";
            }
            if (formData.totalUsageLimit < 1) return "Global Quota must be at least 1.";

            if (formData.allowedCustomers.trim()) {
                const emails = formData.allowedCustomers.split(",").map(e => e.trim());
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                const invalidEmail = emails.find(email => !emailRegex.test(email));
                if (invalidEmail) return `Invalid email detected: ${invalidEmail}`;
            }
        }

        if (tab === "actions") {
            if (formData.discountValue <= 0) return "Discount value must be greater than 0.";
            if (formData.discountType === "1" && formData.discountValue > 100) {
                return "Percentage discount cannot exceed 100%.";
            }
        }

        return null;
    };

    const handleDateChange = (field, value) => {
        const selectedTime = new Date(value).getTime();
        const currentTime = new Date().getTime();

        if (selectedTime < currentTime && field === 'validFrom') {
            setFormData(prev => ({ ...prev, [field]: getLiveDateTime() }));
            setError("Start time cannot be in the past.");
        } else {
            setFormData(prev => ({ ...prev, [field]: value }));
            setError("");
        }
    };

    const handleUpdate = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        setError("");
    };

    const handleNext = (nextTab) => {
        const validationError = validateStep(activeTab);
        if (validationError) {
            setError(validationError);
            return;
        }
        setActiveTab(nextTab);
        setError("");
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const finalError = validateStep("actions");
        if (finalError) {
            setError(finalError);
            return;
        }

        const submissionData = {
            ...formData,
            // If assignedSubAdmin is empty, we send null to the backend
            assignedSubAdmins: formData.assignedSubAdmin || null,
            allowedCustomers: formData.allowedCustomers
                ? formData.allowedCustomers.split(",").map(email => email.trim()).filter(e => e !== "")
                : []
        };

        try {
            await createCoupon(submissionData).unwrap();
            router.push("/coupon/list");
        } catch (err) {
            setError(err?.data?.message || "Internal Server Error: Could not save coupon.");
        }
    };

    const generateCode = () => {
        if (!formData.name.trim()) {
            setError("Rule Name is required to generate a code.");
            return;
        }
        const prefix = formData.name.split(" ")[0].toUpperCase().replace(/[^A-Z0-9]/g, "");
        const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase();
        handleUpdate('code', `${prefix}${randomStr}`);
    };

    return (
        <PermissionGuardian permissionId="coupons">
            <main className="min-h-screen bg-gray-50/50 p-3 sm:p-6 md:p-8 lg:p-10 overflow-x-hidden">
                <div className="w-full mb-8 flex flex-col sm:flex-row items-center justify-between gap-6 border-b border-gray-100 pb-8">
                    <div className="text-center sm:text-left">
                        <PageHeader title="Publish Discount Rule" description="Configure campaign validity and reward logic." />
                        <div className="w-24 h-1.5 bg-indigo-600 rounded-full mt-4 mx-auto sm:mx-0" />
                    </div>
                </div>

                <div className="w-full space-y-6">
                    {error && (
                        <div className="p-4 bg-red-50 border-2 border-red-100 text-red-600 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                            <AlertCircle size={18} /> {error}
                        </div>
                    )}

                    <div className="overflow-x-auto scrollbar-hide -mx-3 px-3 sm:mx-0 sm:px-0">
                        <div className="inline-flex gap-2 p-1.5 bg-white rounded-3xl border border-gray-100 shadow-xl shadow-gray-500/5 min-w-full sm:min-w-max lg:w-fit">
                            <TabButton active={activeTab === "information"} onClick={() => setActiveTab("information")} icon={<Info size={18} />} label="1. Information" />
                            <TabButton active={activeTab === "conditions"} onClick={() => {
                                const err = validateStep("information");
                                if (!err) setActiveTab("conditions"); else setError(err);
                            }} icon={<ShieldCheck size={18} />} label="2. Conditions" />
                            <TabButton active={activeTab === "actions"} onClick={() => {
                                const err = validateStep("information") || validateStep("conditions");
                                if (!err) setActiveTab("actions"); else setError(err);
                            }} icon={<Zap size={18} />} label="3. Actions" />
                        </div>
                    </div>

                    <form onSubmit={handleSubmit} className="bg-white rounded-[2rem] sm:rounded-[2.5rem] border border-gray-100 shadow-2xl overflow-hidden">
                        <div className="p-5 sm:p-10 lg:p-16">
                            {activeTab === "information" && (
                                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 lg:gap-12 animate-in fade-in duration-300">
                                    <div className="space-y-6 sm:space-y-8">
                                        <InputField label="Promotional Rule Name *" placeholder="e.g. Winter Sale 2026" value={formData.name} onChange={(e) => handleUpdate('name', e.target.value)} />
                                        <div className="flex flex-col sm:flex-row items-end gap-4">
                                            <div className="w-full"><InputField label="Public Coupon Code *" placeholder="WINTER50" value={formData.code} onChange={(e) => handleUpdate('code', e.target.value.toUpperCase().replace(/\s/g, ""))} /></div>
                                            <button type="button" onClick={generateCode} className="w-full sm:w-auto h-14 sm:h-16 px-10 bg-indigo-50 text-indigo-600 border-2 border-indigo-100 rounded-2xl font-black uppercase text-[11px] tracking-widest hover:bg-indigo-600 hover:text-white transition-all">Auto-Gen</button>
                                        </div>
                                    </div>
                                    <div className="space-y-3">
                                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Internal Description ({formData.description.length}/120)</label>
                                        <textarea maxLength={120} rows={5} className="text-black w-full p-6 sm:p-8 bg-gray-50/50 border-2 border-gray-100 rounded-[2rem] focus:outline-none focus:border-indigo-500 transition-all font-medium text-base leading-relaxed" placeholder="Briefly describe the purpose of this discount..." value={formData.description} onChange={(e) => handleUpdate('description', e.target.value)} />
                                    </div>
                                </div>
                            )}

                            {activeTab === "conditions" && (
                                <div className="space-y-10 lg:space-y-12 animate-in fade-in duration-300 text-black">
                                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 lg:gap-12">
                                        <div className="space-y-4">
                                            <label className="text-[11px] font-black text-gray-400 uppercase tracking-widest ml-1">Validity Window *</label>
                                            <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_1fr] items-center gap-3">
                                                <div className="relative w-full">
                                                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-500" size={18} />
                                                    <input min={minDateTime} type="datetime-local" className="text-black w-full pl-12 pr-3 h-14 sm:h-16 bg-gray-50/50 border-2 border-gray-100 rounded-2xl font-bold text-xs sm:text-sm focus:border-indigo-500 outline-none transition-all" value={formData.validFrom} onChange={(e) => handleDateChange('validFrom', e.target.value)} />
                                                </div>
                                                <span className="text-[10px] font-black text-gray-300 uppercase text-center">To</span>
                                                <div className="relative w-full">
                                                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-500" size={18} />
                                                    <input min={formData.validFrom || minDateTime} type="datetime-local" className="text-black w-full pl-12 pr-3 h-14 sm:h-16 bg-gray-50/50 border-2 border-gray-100 rounded-2xl font-bold text-xs sm:text-sm focus:border-indigo-500 outline-none transition-all" value={formData.validTill} onChange={(e) => handleDateChange('validTill', e.target.value)} />
                                                </div>
                                            </div>
                                        </div>
                                        
                                        {/* NEW: Referral Sub-Admin Selection */}
                                        <div className="space-y-3">
                                            <label className="text-[11px] font-black text-gray-400 uppercase tracking-widest ml-1 flex items-center gap-2">
                                                <UserCircle2 size={14} className="text-amber-500" /> Assign To Sub-Admin (Optional)
                                            </label>
                                            <select 
                                                value={formData.assignedSubAdmin} 
                                                onChange={(e) => handleUpdate('assignedSubAdmin', e.target.value)}
                                                className="w-full h-14 sm:h-16 px-6 bg-gray-50/50 border-2 border-gray-100 rounded-2xl font-bold text-sm focus:border-indigo-500 outline-none transition-all appearance-none cursor-pointer"
                                            >
                                                <option value="">No Referral (Public Coupon)</option>
                                                {subAdmins.map((admin) => (
                                                    <option key={admin._id} value={admin._id}>
                                                        {admin.name} ({admin.email})
                                                    </option>
                                                ))}
                                            </select>
                                            <p className="text-[9px] font-bold text-amber-500 uppercase mt-1 ml-1 tracking-tighter">
                                                Assigning this will track all sales from this coupon to this sub-admin.
                                            </p>
                                        </div>
                                    </div>

                                    <div className="pt-10 border-t border-gray-50">
                                        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 lg:gap-12 items-start">
                                            <div className="xl:col-span-1">
                                                <InputField label="Min. Cart (₹)" type="number" min="0" value={formData.minCartAmount} onChange={(e) => handleUpdate('minCartAmount', e.target.value)} />
                                            </div>
                                            <div className="xl:col-span-2">
                                                <InputField label="Target Customers (Comma separated emails)" placeholder="user1@gmail.com, user2@gmail.com" value={formData.allowedCustomers} onChange={(e) => handleUpdate('allowedCustomers', e.target.value)} />
                                                <p className="text-[9px] font-bold text-gray-400 uppercase mt-3 ml-1 flex items-center gap-1.5"><Mail size={10} /> Leave empty for general public use.</p>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4 mt-8 max-w-md">
                                            <InputField label="Total Uses" type="number" min="1" value={formData.totalUsageLimit} onChange={(e) => handleUpdate('totalUsageLimit', e.target.value)} />
                                            <InputField label="Per User" type="number" min="1" value={formData.perUserUsageLimit} onChange={(e) => handleUpdate('perUserUsageLimit', e.target.value)} />
                                        </div>
                                    </div>
                                </div>
                            )}

                            {activeTab === "actions" && (
                                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12 animate-in fade-in duration-300 ">
                                    <div className="lg:col-span-2 space-y-6">
                                        <label className="text-[11px] font-black text-gray-400 uppercase tracking-widest block ml-1">Discount Calculation</label>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                            <RadioOption label="Percentage (%)" active={formData.discountType === "1"} onClick={() => handleUpdate('discountType', "1")} />
                                            <RadioOption label="Fixed Amount (₹)" active={formData.discountType === "2"} onClick={() => handleUpdate('discountType', "2")} />
                                        </div>
                                    </div>
                                    <InputField label={`Discount Value ${formData.discountType === "1" ? "(Max 100%)" : "(Flat ₹)"}`} type="number" min="1" value={formData.discountValue} onChange={(e) => handleUpdate('discountValue', e.target.value)} />
                                </div>
                            )}
                        </div>

                        <div className="p-6 sm:p-8 lg:p-12 bg-gray-50/50 border-t border-gray-100 flex justify-end">
                            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                                {activeTab !== "information" && (
                                    <button type="button" onClick={() => setActiveTab(activeTab === "actions" ? "conditions" : "information")} className="w-full sm:w-auto hover:cursor-pointer px-10 py-4 sm:py-5 text-gray-400 font-black uppercase text-[10px] tracking-widest hover:text-indigo-600 transition-all text-center">Back</button>
                                )}
                                {activeTab === "actions" ? (
                                    <button type="submit" disabled={isLoading} className="w-full sm:w-auto hover:cursor-pointer px-12 py-4 sm:py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50">
                                        {isLoading ? <RefreshCw className="animate-spin" size={16} /> : <Check size={18} />} Publish Rule
                                    </button>
                                ) : (
                                    <button type="button" onClick={() => handleNext(activeTab === "information" ? "conditions" : "actions")} className="w-full sm:w-auto hover:cursor-pointer px-12 py-4 sm:py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95">
                                        Save & Continue <ArrowRight size={18} />
                                    </button>
                                )}
                            </div>
                        </div>
                    </form>
                </div>
            </main>
        </PermissionGuardian>
    );
}

/* Internal Components (Maintaining Original Premium Design) */
const TabButton = ({ active, onClick, icon, label }) => (
    <button onClick={onClick} type="button" className={`flex-1 flex items-center justify-center hover:cursor-pointer gap-2 sm:gap-3 px-6 sm:px-10 py-3 sm:py-5 rounded-[1.2rem] transition-all whitespace-nowrap ${active ? 'bg-indigo-600 text-white shadow-xl scale-[1.02]' : 'text-gray-400 hover:bg-gray-50'}`}>
        <span className="opacity-70">{icon}</span>
        <span className="text-[9px] sm:text-[11px] font-black uppercase tracking-widest">{label}</span>
    </button>
);

const InputField = ({ label, onChange, ...props }) => (
    <div className="flex flex-col gap-2 sm:gap-3 w-full text-black">
        <label className="text-[10px] sm:text-[11px] font-black text-gray-400 uppercase tracking-widest ml-1">{label}</label>
        <input {...props} onChange={onChange} className="w-full h-14 sm:h-16 px-5 sm:px-8 bg-gray-50/50 border-2 border-gray-100 rounded-2xl focus:outline-none focus:border-indigo-500 font-bold sm:font-black text-sm sm:text-lg transition-all" />
    </div>
);

const RadioOption = ({ label, active, onClick }) => (
    <button onClick={onClick} type="button" className={`flex items-center gap-3 sm:gap-4 p-4 sm:p-6 rounded-[1.5rem] border-2 transition-all w-full ${active ? 'border-indigo-600 bg-indigo-50 shadow-md' : 'border-gray-100 bg-white'}`}>
        <div className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full border-4 flex items-center justify-center ${active ? 'border-indigo-600 bg-indigo-600 shadow-sm' : 'border-gray-200 bg-white'}`}>
            {active && <div className="w-2 h-2 rounded-full bg-white" />}
        </div>
        <span className={`text-[10px] sm:text-[12px] font-black uppercase tracking-wider ${active ? 'text-gray-900' : 'text-gray-400'}`}>{label}</span>
    </button>
);